#!/bin/sh
java -jar mapreduce.jar